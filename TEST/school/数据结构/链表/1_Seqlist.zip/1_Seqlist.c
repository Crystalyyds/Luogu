#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#define ERROR 0
#define OK 1
#define Overflow 2   // Overflow ��ʾ����
#define Underflow 3  // Underflow ��ʾ����
#define NotPresent 4 // NotPresent ��ʾԪ�ز�����
#define Duplicate 5  // Duplicate ��ʾ���ظ�Ԫ��
typedef int Status;
typedef int ElemType;
typedef struct
{
    int n;             // ˳����ĵ�ǰ����
    int maxLength;     // ˳����������������
    ElemType *element; // ��̬һά�����ָ��
} SeqList;

Status Init(SeqList *L, int mSize)
{
    L->maxLength = mSize;
    L->n = 0;
    L->element = (ElemType *)malloc(sizeof(ElemType) * mSize); // ��̬����һά����ռ�
    if (!L->element)
        return ERROR;
    return OK;
}

Status Find(SeqList L, int i, ElemType *x)
{
    if (i < 0 || i > L.n - 1)
        return ERROR;  // �ж�Ԫ���±�i �Ƿ�Խ��
    *x = L.element[i]; // ȡ��element[i]ֵͨ������x ����
    return OK;
}

Status Insert(SeqList *L, int i, ElemType x)
{
    int j;
    if (i < -1 || i > L->n - 1) // �ж��±�i �Ƿ�Խ��
        return ERROR;
    if (L->n == L->maxLength) // �жϴ洢�ռ��Ƿ�����
        return ERROR;
    for (j = L->n - 1; j > i; j--)
        L->element[j + 1] = L->element[j]; // �Ӻ���ǰ�������Ԫ��
    L->element[i + 1] = x;                 // ����Ԫ�ط����±�Ϊi+1 ��λ��
    L->n = L->n + 1;
    return OK;
}

Status Delete(SeqList *L, int i)
{
    int j;
    if (!L->n) // ˳����Ƿ�Ϊ��
        return ERROR;
    if (i < 0 || i > L->n - 1) // �±�i �Ƿ�Խ��
        return ERROR;
    for (j = i + 1; j < L->n; j++)
        L->element[j - 1] = L->element[j]; // ��ǰ�������ǰ��Ԫ��
    L->n--;                                // ������1
    return OK;
}

Status Output(SeqList L)
{
    int i;
    if (L.n == 0) // �ж�˳����Ƿ�Ϊ��
        return ERROR;
    printf("Print all elements:\n");
    for (i = 0; i <= L.n - 1; i++)
        printf("%d ", L.element[i]); // ��ǰ����������Ԫ��
    printf("\n");
    return OK;
}

Status Reverse(SeqList *L)
{
    int i;
    if (L->n == 0) // �ж�˳����Ƿ�Ϊ��
        return ERROR;
    for (i = 0; i < L->n / 2; i++)
    {
        int temp = L->element[i];
        L->element[i] = L->element[L->n - i - 1];
        L->element[L->n - i - 1] = temp;
    }
    return OK;
}

void Destroy(SeqList *L)
{
    L->n = 0;
    L->maxLength = 0;
    free(L->element);
}

Status find2(SeqList L, int *pos, ElemType x)
{
    for (int i = 0; i < L.n; i++)
    {
        if (x == L.element[i])
            return OK;
    }
    return ERROR;
}

Status Sort(SeqList *L)
{
    if (L->n == 0)
        return ERROR;
    for (int i = 0; i < L->n; i++)
    {
        for (int j = 0; j < L->n; j++)
        {
            if (L->element[j] > L->element[j + 1])
            {
                int temp = L->element[j];
                L->element[j] = L->element[j + 1];
                L->element[j + 1] = temp;
                // swap(L->element[j], L->element[j + 1]);
                // L->element[j - 1] = L->element[j + 1];
                // L->element[j + 1] = L->element[j];
                // L->element[j] = L->element[j + 2];
            }
        }
    }
    return OK;
}

Status Insert2(SeqList *L, ElemType x)
{
    if (L->n >= L->maxLength)
        return ERROR;
    Sort(L);
    for (int j = L->n - 1; j >= 0; j--)
    {
        if (L->element[j] < x)
        {
            L->element[j + 1] = x;
            return OK;
        }
        L->element[j + 1] = L->element[j];
    }
}

Status Delete2(SeqList *L, ElemType x)
{
    if (L->n == 0)
        return ERROR;
    for (int i = 0; i < L->n - 1; i++)
    {
        if (L->element[i] == x)
        {
            for (int j = i; j < L->n - 1; j++)
            {
                L->element[j] = L->element[j + 1];
            }
            return OK;
        }
    }
    return ERROR;
}
void menu()
{
    printf("----1:��ʼ��˳���----\n");
    printf("----2:����Ԫ��----\n");
    printf("----3:����Ԫ��----\n");
    printf("----4:ɾ��Ԫ��----\n");
    printf("----5:�������Ԫ��----\n");
    printf("----6:˳�������----\n");
    printf("----7:����˳���----\n");
    printf("----8:����2----\n");
    printf("----9:����----\n");
    printf("----10:ָ������2----\n");
    printf("----11:ָ��ɾ��----\n");
    printf("----0:�˳�����----\n");
}

int main()
{
    int choice, size, pos, elem, x;
    SeqList list;
    do
    {
        menu();
        printf("Please input one choice(0--6)\n");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:
            printf("Please input the length of SeqList:\n");
            scanf("%d", &size);
            Init(&list, size); // ��˳������г�ʼ��
            break;
        case 2:
            printf("Please input position found:\n");
            scanf("%d", &pos);
            if (Find(list, pos, &elem))
                printf("the element is:%d\n", elem);
            else
                printf("the position does not exist\n");
            break;
        case 3:
            printf("Please input position and element:\n");
            scanf("%d%d", &pos, &elem);
            if (!Insert(&list, pos, elem))
                printf("no space or error position!\n"); // ���Ա��в�����Ԫ��
            break;
        case 4:
            printf("Please input position found:\n");
            scanf("%d", &pos);
            if (Delete(&list, pos))
                printf("one element is deleted!\n");
            else
                printf("no element is deleted!\n");
            break;
        case 5:
            if (!Output(list))
                printf("SeqList is empty!\n");
            break;
        case 6:
            Reverse(&list);
            break;
        case 7:
            Destroy(&list);
            printf("the list is destroyed!\n");
            break;
        case 8:
            scanf("%d%d", &pos, &x);
            if (find2(list, &pos, x))
                printf("�ҵ���");
            else
                printf("û���ҵ�");
            break;
        case 9:
            Sort(&list);
            printf("the list is sorted");
            break;
        case 10:
            scanf("%d", &x);
            Insert2(&list, x);
            printf("the list is insert!\n");
            break;
        case 11:
            scanf("%d", &x);
            Delete2(&list, x);
            printf("the list is delete!\n");
            break;
        case 0:
            break;
        default:
            printf("error input!\n");
        }
    } while (choice);
    return 0;
}